<?php
/**
 * The main template file
 *
 *
 * @package Techtrails Toolkit
 * @version 1.0
 */

 if($_SERVER['HTTP_HOST'] !== 'techtrails.local') {
	header("Location: https://toolkit.techtrails.com");
 }

 
die(); ?>